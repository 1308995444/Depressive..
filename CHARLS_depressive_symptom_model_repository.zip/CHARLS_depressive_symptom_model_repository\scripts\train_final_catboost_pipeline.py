"""Train and evaluate depressive symptom prediction models.

This script is a sanitized public entry point for the CHARLS depressive symptom
risk prediction analysis. Raw CHARLS data are not redistributed in this repository.
Place the three preprocessed split files under ./data/ using the filenames listed
below, then run this script from the repository root.
"""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_DIR = Path("data")
OUTPUT_DIR = Path("outputs")
MODEL_DIR = Path("models")
OUTPUT_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = ['gender', 'gastric_disease', 'pain', 'sleep_duration_night', 'retirement_status', 'self_rated_health', 'adl_disability', 'future_hope', 'life_satisfaction', 'education_level', 'chronic_disease_count', 'hearing_ability']
TARGET = 'depressive_symptoms'
CATEGORICAL_COLS = ['gender', 'gastric_disease', 'pain', 'retirement_status', 'self_rated_health', 'future_hope', 'life_satisfaction', 'education_level', 'hearing_ability']
NUMERICAL_COLS = ['sleep_duration_night', 'adl_disability', 'chronic_disease_count']


def load_split(filename: str):
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. See data/README.md for data access and expected schema.")
    df = pd.read_csv(path, encoding="GB18030")
    data = df[FEATURES + [TARGET]].copy()
    return data.drop(columns=[TARGET]), data[TARGET].astype(int)


def build_preprocessor():
    cat_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(drop="first", sparse_output=False, handle_unknown="ignore")),
    ])
    num_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    return ColumnTransformer([
        ("cat", cat_transformer, CATEGORICAL_COLS),
        ("num", num_transformer, NUMERICAL_COLS),
    ])


def build_final_catboost_pipeline():
    return ImbPipeline([
        ("preprocessor", build_preprocessor()),
        ("smote", SMOTE(random_state=42)),
        ("classifier", CatBoostClassifier(
            eval_metric="AUC",
            random_state=40,
            iterations=3000,
            verbose=0,
            early_stopping_rounds=60,
            use_best_model=False,
            auto_class_weights="Balanced",
            bagging_temperature=0.5,
            colsample_bylevel=0.6,
            depth=3,
            l2_leaf_reg=5,
            learning_rate=0.07,
            min_data_in_leaf=20,
            random_strength=2.0,
            subsample=0.8,
        )),
    ])


def metric_summary(y_true, prob, threshold=0.5):
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    return {
        "threshold": threshold,
        "n": len(y_true),
        "tp": int(tp),
        "fp": int(fp),
        "tn": int(tn),
        "fn": int(fn),
        "accuracy": accuracy_score(y_true, pred),
        "sensitivity": recall_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "specificity": tn / (tn + fp),
        "f1": f1_score(y_true, pred),
        "auc": roc_auc_score(y_true, prob),
        "brier": brier_score_loss(y_true, prob),
    }


def main():
    x_train, y_train = load_split("charls(2018-train).csv")
    x_test, y_test = load_split("charls(2018-test).csv")
    x_val, y_val = load_split("charls(2013).csv")

    model = build_final_catboost_pipeline()
    model.fit(x_train, y_train)
    joblib.dump(model, MODEL_DIR / "catboost_smote_pipeline.joblib")

    rows = []
    for name, x, y in [("Train", x_train, y_train), ("Internal test", x_test, y_test), ("Temporal validation", x_val, y_val)]:
        prob = model.predict_proba(x)[:, 1]
        row = {"dataset": name, **metric_summary(y, prob)}
        rows.append(row)
        print(name, row)
    pd.DataFrame(rows).to_csv(OUTPUT_DIR / "catboost_final_metrics.csv", index=False)


if __name__ == "__main__":
    main()
