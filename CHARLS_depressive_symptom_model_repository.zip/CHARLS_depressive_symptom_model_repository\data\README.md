# Data Directory

Place authorized, preprocessed CHARLS split files in this directory before running the scripts.

Required filenames:

- `charls(2018-train).csv`
- `charls(2018-test).csv`
- `charls(2013).csv`

Required columns:

- Predictors: gender, gastric_disease, pain, sleep_duration_night, retirement_status, self_rated_health, adl_disability, future_hope, life_satisfaction, education_level, chronic_disease_count, hearing_ability
- Outcome: `depressive_symptoms`

Raw CHARLS data are not redistributed in this repository. Users should obtain data directly from CHARLS and apply the cohort selection and preprocessing pipeline described in the manuscript.
