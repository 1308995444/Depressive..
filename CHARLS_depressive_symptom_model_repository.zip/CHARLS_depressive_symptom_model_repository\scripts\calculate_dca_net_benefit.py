from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


DATA_DIR = Path("data")
OUT_DIR = Path("outputs/dca_net_benefit")
OUT_DIR.mkdir(exist_ok=True)

FEATURES = [
    "gender",
    "gastric_disease",
    "pain",
    "sleep_duration_night",
    "retirement_status",
    "self_rated_health",
    "adl_disability",
    "future_hope",
    "life_satisfaction",
    "education_level",
    "chronic_disease_count",
    "hearing_ability",
]
TARGET = "depressive_symptoms"
CATEGORICAL_COLS = [
    "gender",
    "gastric_disease",
    "pain",
    "retirement_status",
    "self_rated_health",
    "future_hope",
    "life_satisfaction",
    "education_level",
    "hearing_ability",
]
NUMERICAL_COLS = ["sleep_duration_night", "adl_disability", "chronic_disease_count"]
THRESHOLDS = [0.05, 0.10, 0.15, 0.20, 0.25, 0.263, 0.30, 0.35, 0.40, 0.50]


def load_split(filename):
    df = pd.read_csv(DATA_DIR / filename, encoding="GB18030")
    data = df[FEATURES + [TARGET]].copy()
    return data.drop(columns=[TARGET]), data[TARGET].astype(int)


def preprocess(x_train, x_test, x_val):
    cat_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(drop="first", sparse_output=False)),
        ]
    )
    num_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", cat_transformer, CATEGORICAL_COLS),
            ("num", num_transformer, NUMERICAL_COLS),
        ]
    )
    x_train_p = preprocessor.fit_transform(x_train)
    x_test_p = preprocessor.transform(x_test)
    x_val_p = preprocessor.transform(x_val)
    cat_features = preprocessor.named_transformers_["cat"]["onehot"].get_feature_names_out(CATEGORICAL_COLS)
    all_features = list(cat_features) + NUMERICAL_COLS
    return (
        pd.DataFrame(x_train_p, columns=all_features),
        pd.DataFrame(x_test_p, columns=all_features),
        pd.DataFrame(x_val_p, columns=all_features),
    )


def fit_final_model(x_train, y_train):
    model = ImbPipeline(
        steps=[
            ("smote", SMOTE(random_state=42)),
            (
                "classifier",
                CatBoostClassifier(
                    eval_metric="AUC",
                    random_state=40,
                    iterations=3000,
                    verbose=0,
                    use_best_model=False,
                    auto_class_weights="Balanced",
                    bagging_temperature=0.5,
                    colsample_bylevel=0.6,
                    depth=3,
                    l2_leaf_reg=5,
                    learning_rate=0.07,
                    min_data_in_leaf=20,
                    random_strength=2.0,
                    subsample=0.8,
                ),
            ),
        ]
    )
    model.fit(x_train, y_train, classifier__verbose=False)
    return model


def metric_summary(y_true, prob, threshold=0.5):
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    return {
        "threshold": threshold,
        "n": len(y_true),
        "tp": int(tp),
        "fp": int(fp),
        "tn": int(tn),
        "fn": int(fn),
        "accuracy": accuracy_score(y_true, pred),
        "sensitivity": recall_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "specificity": tn / (tn + fp),
        "f1": f1_score(y_true, pred),
        "auc": roc_auc_score(y_true, prob),
        "brier": brier_score_loss(y_true, prob),
    }


def net_benefit(y_true, prob, threshold):
    pred = prob >= threshold
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    n = len(y_true)
    model_nb = (tp / n) - (fp / n) * (threshold / (1 - threshold))
    prevalence = y_true.mean()
    treat_all_nb = prevalence - (1 - prevalence) * (threshold / (1 - threshold))
    return model_nb, treat_all_nb, 0.0, int(tp), int(fp), int(tn), int(fn)


def dca_table(y_true, prob, dataset):
    rows = []
    for threshold in THRESHOLDS:
        model_nb, treat_all_nb, treat_none_nb, tp, fp, tn, fn = net_benefit(y_true, prob, threshold)
        rows.append(
            {
                "Dataset": dataset,
                "Threshold probability": threshold,
                "CatBoost net benefit": model_nb,
                "Treat-all net benefit": treat_all_nb,
                "Treat-none net benefit": treat_none_nb,
                "TP": tp,
                "FP": fp,
                "TN": tn,
                "FN": fn,
            }
        )
    return pd.DataFrame(rows)


def main():
    x_train, y_train = load_split("charls(2018-train).csv")
    x_test, y_test = load_split("charls(2018-test).csv")
    x_val, y_val = load_split("charls(2013).csv")
    x_train_p, x_test_p, x_val_p = preprocess(x_train, x_test, x_val)
    model = fit_final_model(x_train_p, y_train)

    test_prob = model.predict_proba(x_test_p)[:, 1]
    val_prob = model.predict_proba(x_val_p)[:, 1]

    print("Final SMOTE + CatBoost metrics at 0.5")
    print("Test:", metric_summary(y_test, test_prob))
    print("Temporal validation:", metric_summary(y_val, val_prob))
    print("Temporal validation at threshold 0.263:", metric_summary(y_val, val_prob, threshold=0.263))

    out = pd.concat(
        [
            dca_table(y_test, test_prob, "Internal test set"),
            dca_table(y_val, val_prob, "Temporal validation set"),
        ],
        ignore_index=True,
    )
    out.to_csv(OUT_DIR / "catboost_final_pipeline_dca_net_benefit_values.csv", index=False, encoding="utf-8-sig")

    rounded = out.copy()
    for col in ["Threshold probability", "CatBoost net benefit", "Treat-all net benefit", "Treat-none net benefit"]:
        rounded[col] = rounded[col].map(lambda v: f"{v:.3f}")
    rounded.to_csv(
        OUT_DIR / "catboost_final_pipeline_dca_net_benefit_values_rounded.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("\nDCA net benefit values from final SMOTE + CatBoost pipeline:")
    print(rounded.to_string(index=False))


if __name__ == "__main__":
    main()
