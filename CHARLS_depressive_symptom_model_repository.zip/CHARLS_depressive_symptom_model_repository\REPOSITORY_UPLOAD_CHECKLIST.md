# Repository Upload Checklist

## Include

- `README.md`
- `requirements.txt`
- `runtime.txt`
- `notebooks/main_analysis_sanitized.ipynb`
- `scripts/train_final_catboost_pipeline.py`
- `scripts/calculate_dca_net_benefit.py`
- `data/README.md`
- `models/README.md`
- `config/example_config.json`
- trained model object only if permitted: `models/catboost_model.pkl`

## Do not include

- Raw CHARLS data: `*.csv`, `*.xlsx`, `*.sav`, `*.dta`
- Local manuscript files: `*.docx`, response letters, reviewer comments
- Local absolute paths containing user names or desktop folders
- Notebook outputs containing tables copied from private files
- `.Rhistory`, temporary scripts, backup documents, generated drafts
- API keys, passwords, tokens, browser/session files

## Manual items before submission

- Replace `[repository URL]` in the manuscript and response letter with the final public repository URL.
- Confirm whether the trained model object may be shared under CHARLS and journal policies.
- Add a license if required by the target journal or institution.
