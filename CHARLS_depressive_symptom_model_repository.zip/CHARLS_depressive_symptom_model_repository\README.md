# Depressive Symptom Risk Prediction in CHARLS

This repository contains sanitized code and reproducibility materials for the manuscript **Development and Validation of a Machine Learning Model for Predicting Depressive Symptom Risk in Middle-Aged and Elderly Patients with Chronic Diseases in Community Settings**.

## Repository contents

- `notebooks/main_analysis_sanitized.ipynb`: cleaned notebook with outputs removed and local file paths replaced by relative paths.
- `scripts/train_final_catboost_pipeline.py`: public script for fitting the final SMOTE + CatBoost pipeline and exporting metrics.
- `scripts/calculate_dca_net_benefit.py`: script for calculating decision-curve net benefit values.
- `data/README.md`: data access instructions and expected input file schema. Raw CHARLS data are not redistributed.
- `models/catboost_model.pkl`: trained model object, if sharing is permitted by journal/data-use rules.
- `requirements.txt` and `runtime.txt`: Python environment details.
- `REPOSITORY_UPLOAD_CHECKLIST.md`: pre-upload privacy and reproducibility checklist.

## Data availability

The raw data are available from the China Health and Retirement Longitudinal Study (CHARLS): http://charls.pku.edu.cn/index/en.html. Because CHARLS data are governed by their own access and use terms, individual-level raw data files are not included in this repository.

Expected local data files after authorized access and preprocessing:

- `data/charls(2018-train).csv`
- `data/charls(2018-test).csv`
- `data/charls(2013).csv`

## Quick start

```bash
python -m venv .venv
.venv\Scripts\activate  # Windows
pip install -r requirements.txt
python scripts/train_final_catboost_pipeline.py
python scripts/calculate_dca_net_benefit.py
```

## Privacy note

All local absolute paths, user names, desktop directories, notebook outputs, and raw data files have been removed from the public materials. Do not commit raw CHARLS CSV/XLSX files, manuscript files, response letters, local backups, or temporary outputs.

## Leakage-control note

The temporal validation cohort is not used for preprocessing, feature selection, hyperparameter tuning, threshold selection, or early stopping in the public scripts.
